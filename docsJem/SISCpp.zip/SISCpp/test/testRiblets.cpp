
#include <fstream> // To output data to files
#include <iostream>
#include <stdio.h>
#include <sis.hpp>

#include <eigen3/unsupported/Eigen/MatrixFunctions>

using namespace std;
#ifndef CD_T
typedef complex<double> Cd_t;
#endif

typedef valarray<Cd_t> Vcd_t;
//#define DEBUG

#include <lyap.h>

int main()
{
    //Tau formulation, discriptor system :
    int N = 91;
    Cd_t ii(0,1); // imaginary unit.
    Eigen::VectorXd kzval = Eigen::VectorXd::LinSpaced(10, 1.0, 4.0);
   // for (int i = 0; i <  10; i++){ 
        double kx = 1;
        //double kz = kzval(i);
        double kz = 1.0;
        double k2 = kx * kx + kz * kz;
        double  k4 = k2 * k2;
        double R = 2000;
        Eigen::MatrixXcd Dmat = Eigen::MatrixXcd::Zero(N + 1, N + 1);
        Eigen::MatrixXcd Dpmat = Eigen::MatrixXcd::Zero(N - 1, N - 1);
        for (int k = 0; k < N + 1; k++) {
            for (int p = k + 1; p < N + 1; p++) {
                if ((p + k) % 2) {
                    Dmat(k, p) = p;
                }
            }
        }
        cout << "line: " << __LINE__ << endl << flush;
        for (int k = 0; k < N - 1; k++) {
            for (int p = k + 1; p < N - 1; p++) {
                if ((p + k) % 2) {
                    Dpmat(k, p) = p;
                }
            }
        }
        cout << "line: " << __LINE__ << endl
             << flush;
        Dmat = Dmat * 2.0;
        Dpmat = Dpmat * 2.0;
        Eigen::MatrixXcd If = Eigen::MatrixXcd::Identity(N + 1, N + 1);
        Eigen::MatrixXcd Ip = Eigen::MatrixXcd::Identity(N - 1, N - 1);
        Eigen::MatrixXcd D1f = Dmat * If;
        Eigen::MatrixXcd D2f = D1f * D1f;
        Eigen::MatrixXcd D1p = Dpmat * Ip;
        Eigen::MatrixXcd D2p = Dpmat * Dpmat;
        cout << "line: " << __LINE__ << endl
             << flush;
        // Make discretization matrices : % First verify eigenvalues :
        Eigen::MatrixXcd bc1(1, N + 1);
        bc1.setConstant(1.0);
        Eigen::MatrixXcd bc2(1, N + 1);
        for (int i = 0; i < N + 1; i++){
            bc2(0, i) = pow(-1.0, i);
        }
    //bc2 = (-1).^ (0: N);
    bc1(0,0) = 0.5 * bc1(0,0);
    bc2(0,0) = 0.5 * bc2(0,0);
    cout << "line: " << __LINE__ << endl
         << flush;
    Eigen::MatrixXcd I = If.block(0, 0, N - 1, N + 1);
    //I = If(1: N - 1,:);
    Eigen::MatrixXcd D1 = D1f.block(0, 0, N - 1, N + 1);
    //D1 = D1f(1: N - 1,:);
    Eigen::MatrixXcd D2 = D2f.block(0, 0, N - 1, N + 1);
    //D2 = D2f(1: N - 1,:);
    Eigen::MatrixXcd E(4 * (N - 1) + 6, 4 * (N - 1) + 6), F(4 * (N - 1) + 6, 4 * (N - 1) + 6), B(4 * (N - 1) + 6, 3 * (N - 1)), C(3 * (N + 1), 3 * (N + 1) + N - 1);
    cout << "line: " << __LINE__ << endl
         << flush;
    E << I, 0.0 * I, I * 0.0, 0.0 * Ip, //
        0.0 * I,  I, I * 0.0, 0.0 * Ip,  //
        0.0 * I,  0.0 * I, I , 0.0 * Ip,  //
        0.0 * I, 0.0 * I, I * 0.0, 0.0 * Ip,  //
        Eigen::MatrixXcd::Zero(6, 3 * (N + 1) + N - 1);
    //    E = [ I, 0 * I, 0 * I, 0 * Ip;
    //          0 * I, I, 0 * I, 0 * Ip;
    //          0 * I, 0 * I, I, 0 * Ip;
    //          0 * I, 0 * I, 0 * I, 0 * Ip;
    //          zeros(6, 3 * (N + 1) + N - 1) ];
    cout << "line: " << __LINE__ << endl
         << flush;
    sis::N = N-2;
    sis::sis_setup();
    cout << "line: " << __LINE__ << endl
         << flush;
    Eigen::MatrixXcd U = sis::Chebfun<Cd_t>(Vcd_t(1.0 - pow(sis::yc, 2))).MultMat();
    Eigen::MatrixXcd Uy = -sis::Chebfun<Cd_t>(Vcd_t(2.0 * sis::yc)).MultMat();
    cout << "line: " << __LINE__ << endl
         << flush;
    //    U = MultMat(1 - y2.^ 2);
    //    Uy = -MultMat(2 * y2);
    Eigen::MatrixXcd Delta = D2 - k2 * I;
    Eigen::MatrixXcd Diag = (1 / R) * Delta - ii * kx * U * I;
    cout << "line: " << __LINE__ << endl
         << flush;
    F <<  Diag, -Uy * I, I * 0, -ii * kx * Ip,//
          I * 0, Diag, I * 0, -D1p,//
          I * 0, I * 0, Diag, -ii * kz * Ip,//
          ii * kx * I, D1, ii * kz * I, 0 * Ip,//
          bc1, bc1 * 0, bc1 * 0, Eigen::MatrixXcd::Zero(1, N - 1),//
          bc2, bc2 * 0, bc2 * 0, Eigen::MatrixXcd::Zero(1, N - 1),//
          0 * bc1, bc1, bc1 * 0, Eigen::MatrixXcd::Zero(1, N - 1),//
          0 * bc2, bc2, bc2 * 0, Eigen::MatrixXcd::Zero(1, N - 1),//
          0 * bc1, bc1 * 0, bc1, Eigen::MatrixXcd::Zero(1, N - 1),//
          0 * bc2, bc2 * 0, bc2, Eigen::MatrixXcd::Zero(1, N - 1);
    cout << "line: " << __LINE__ << endl
         << flush;
    B << Ip, Ip*0, Ip*0,//
        Ip*0,Ip, Ip*0,//
        Ip*0, Ip*0, Ip,//
        Eigen::MatrixXcd::Zero(N-1+6, 3*(N-1));
    cout << "line: " << __LINE__ << endl
         << flush;
    // B = [blkdiag(eye(N - 1), eye(N - 1), eye(N - 1)); zeros((N - 1) + 6, 3 * (N - 1))];

    C << If, 0 * If, 0 * If, Eigen::MatrixXcd::Zero(N + 1, N - 1), //
        0 * If, If, 0 * If, Eigen::MatrixXcd::Zero(N + 1, N - 1),  //
        0 * If, 0 * If, If, Eigen::MatrixXcd::Zero(N + 1, N - 1);
        //C = [ If, 0 * If, 0 * If, zeros(N + 1, N - 1);
        //        0 * If, If, 0 * If, zeros(N + 1, N - 1);
        //        0 * If, 0 * If, If, zeros(N + 1, N - 1) ];
    cout << "line: " << __LINE__ << endl
         << flush;
    // Verify eigensystem:
    OrdQz qz(F,E);
    cout << "line: " << __LINE__ << endl
         << flush;
    Eigen::MatrixXcd evals = qz.alpha.array()/qz.beta.array();
    cout << "line: " << __LINE__ << endl
         << flush;
    cout << "Showing the eigenvalues: " << evals << endl;
    int bre;
    cin >> bre;
    cout << "info: " << qz.info << endl;
    Eigen::ColPivHouseholderQR<Eigen::Matrix<std::complex<double>, Eigen::Dynamic, Eigen::Dynamic> > qr;
    qr.compute(qz.T.block(0, 0, qz.M, qz.M));
    cout << "is invertible: " << qr.isInvertible() << endl;
    //for (int i = 0; i < qz.alpha.size(); i++){
    //    cout << criteria_(qz.alpha(i,0),qz.beta(i,0)) << endl;
    //    cout << "qz.beta: " << qz.beta(i,0) << endl;
    //}
/*
    Eigen::MatrixXcd Iw = intWts(N);
    Eigen::MatrixXcd Iwp = intWts(N - 2);

    S1p = blkdiag(Iwp, Iwp, Iwp);
    sqrtmS1p = sqrtm(S1p);
    invsqrtmS1p = sqrtmS1p\eye(size(sqrtmS1p));

    S1 = blkdiag(Iw, Iw, Iw);
    sqrtmS1 = sqrtm(S1);
    invsqrtmS1 = sqrtmS1\eye(size(sqrtmS1));

    S2 = blkdiag(Iw, Iw, Iw, Iwp);
    sqrtmS2 = sqrtm(S2);
    invsqrtmS2 = sqrtmS2\eye(size(sqrtmS2));
    invIw = eye(N + 1)\Iw;

    % In new coordinates : Es = sqrtmS2 *E *invsqrtmS2;
    Fs = sqrtmS2 * F * invsqrtmS2;
    Bs = sqrtmS2 * B * invsqrtmS1p;
    Cs = sqrtmS1 * C * invsqrtmS2;
    Es = complex(Es, zeros(size(Es)));

    [ AAS, BBS, Qs, Zs, alp, bet, info ] = ordqzLapack(Fs, Es);

    % [ AA, BB, Q, Z, V, W ] = qz(Fs, Es);
    % [ AAS, BBS, QS, ZS ] = ordqz(AA, BB, Q, Z, 'lhp');
    evals = alp./ bet;
    [ r, c ] = size(AAS);
    isinfE = isinf(evals);
    sumisinfE = sum(isinfE);
    p = r - sumisinfE;
    W = QS '; T = ZS';
    Ff = AAS(1
             : p, 1
             : p);
    Fu = AAS(1
             : p, p + 1
             : end);
    Finf = AAS(p + 1
               : end, p + 1
               : end);

    Ef = BBS(1
             : p, 1
             : p);
    Eu = BBS(1
             : p, p + 1
             : end);
    Einf = BBS(p + 1
               : end, p + 1
               : end);
    [ Y, Z ] = solveCoupledSylvester(Ef, Einf, -Eu, Ff, Finf, -Fu);
    % check norms : norm(Ef * Y - Z * Einf + Eu)
                        norm(Ff * Y - Z * Finf + Fu)
                            [r, c] = size(Z);
    [ ry, cy ] = size(Y);
    [ r1, c1 ] = size(W);
    [ re, ce ] = size(Es);
    [ rt, ct ] = size(T);
    V = W * [ eye(r, re - c), Z; zeros(r1 - r, re - c), eye(r1 - r, c) ];
    U = [ eye(ry, rt - cy), -Y; zeros(ce - ry, r1 - cy), eye(ce - ry, c) ] * T;
    % Check norms : norm(Es - V * blkdiag(Ef, Einf) * U)
                        norm(Fs - V * blkdiag(Ff, Finf) * U)

                            [rv, cv] = size(V);
    [ ref, cef ] = size(Ef);
    [ rfinf, cfinf ] = size(Finf);

    % Solve generalized Lyapunov equations : invEfFf = Ef\Ff;
Ftilde = W'*(Bs*Bs')*W;
Ftilde1 = Ftilde(1
                 : ref, 1
                 : cef);
Ftilde2 = Ftilde(1
                 : ref, cef + 1
                 : end);
Ftilde3 = Ftilde(ref + 1
                 : end, 1
                 : cef);
Ftilde4 = Ftilde(ref + 1
                 : end, cef + 1
                 : end);
Gc1 = lyap(invEfFf, Ftilde1 - Ftilde2 * Z ' - Z*Ftilde3 + Z*Ftilde4*Z');
Gc1 = Ef\(Gc1/(Ef'));
Gc = T'*[Gc1, zeros(ref,ct-cef);
              zeros(ct-cef,cef),zeros(ct-cef,ct-cef)]*T;
invFinfEinf = Finf\Einf;
Gnc4 = dlyap(invFinfEinf,-Ftilde4);
Gnc4 = Finf\(Gnc4/(Finf'));
Gnc = T'*[Y*Gnc4*Y', Y*Gnc4;
          Gnc4*Y', Gnc4]*T;

Gc = sqrtmS2*Gc*invsqrtmS2;
Gnc = sqrtmS2*Gnc*invsqrtmS2;

 normVec(i) = trace(Cs*(Gc+Gnc)*Cs');
end



% Iw4 = blkdiag(Iw,Iw,Iw,Iw);
% Iw3 = blkdiag(Iw,Iw,Iw);
% invIw4 = eye((N+1)*4)\Iw4;
% invIw3 = eye((N+1)*3)\Iw3;
% nullbc1 = blkdiag(nullbcs,nullbcs,nullbcs,eye(90,90));
% % Now come to calculating the H2 norm:
% C = [If, 0*If, 0*If, zeros(92,90);
%     0*If, If, 0*If, zeros(92,90);
%     0*If, 0*If, If, zeros(92,90)]*nullbc1*nullcont;
% Q = C'*Iw3*C;

*/
    

    return 0;
}